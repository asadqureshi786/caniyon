const nodemailer = require('nodemailer');

exports.handler = async function (event, context) {
  const { name, email,subject ,message } = JSON.parse(event.body);

  const transporter = nodemailer.createTransport({
    host: '',
    port: 587,
    secure: false, // Use TLS
    auth: {
      user: '', // Replace with your Gmail
      pass: '',    // Use App Password
    },
  });

  const mailOptions = {
    from: '',
    to: 'hamdanbaig147@gmail.com',    // Replace with your email
    subject: subject || `New message from ${name}`,
    text: message,
  };

  try {
    await transporter.sendMail(mailOptions);
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Email sent successfully' }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Error sending email', details: error.toString() }),
    };
  }
};
