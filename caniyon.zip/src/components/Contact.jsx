import { PiWarningCircleLight } from "react-icons/pi";
import { IoIosCall } from "react-icons/io";
import { MdOutlineEmail } from "react-icons/md";
import { Row, Col } from 'react-bootstrap';
import React, { useState } from 'react';
// import axios from "axios";



export default function Contact() {

    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: '',
    });

    function setValue(e){
        const {name, value} = e.target;
        setFormData((previous) =>({
            ...previous,[name]: value
        }))
    }

async function sendForm(e) {
  e.preventDefault();

  const res = await fetch('/.netlify/functions/sendEmail', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: formData.name,
        email: formData.email,
        subject: formData.subject,
        message: formData.message,
      }),
    });

    console.log(formData);
    
    const data = await res.json();

    if (res.ok) {
      alert('Email sent!');
      setFormData({ name: '', email: '', subject: '', message: '' });
    } else {
      alert('Error sending email');
      console.error(data);
    }
}




    return (
        <>
            <Row className='pb-1 mt-5 pt-5 mb-4 justify-content-center' id="contact" >
                <Col md={6}>
                    <div className="contact_us" data-aos="fade-up" >
                        <div className="text-center">
                            <div className="subHead">
                                <PiWarningCircleLight /><span className='text' >Find Us</span>
                            </div>
                            <p className="bigT white my-2">Let'Get In <span class="sm_unique" >Touch</span> </p>
                            <p className="text white subText">Contact us for more information or assistance.</p>
                        </div>
                    </div>
                    <div class="form_list" data-aos="fade-up" >
                        <form onSubmit={sendForm} >
                            <Row>
                                <Col md={12}>
                                    <div className="form-group">
                                        <label>Name</label>
                                        <input type="text" name="name" onChange={setValue} value={formData.name} class="form-control" />
                                    </div>
                                </Col>
                                <Col md={12}>
                                    <div className="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" onChange={setValue} value={formData.email} class="form-control" />
                                    </div>
                                </Col>
                                <Col md={12}>
                                    <div className="form-group">
                                        <label>Subject</label>
                                        <input type="text" name="subject" onChange={setValue} value={formData.subject} class="form-control" />
                                    </div>
                                </Col>
                                <Col md={12}>
                                    <div className="form-group">
                                        <label>Message</label>
                                        <textarea rows={6} name="message" onChange={setValue} value={formData.message} className='form-control' ></textarea>
                                    </div>
                                </Col>
                                <Col md={12}>
                                    <div class="d-flex justify-content-center mt-2">
                                        <button className='btn btn-primary' type="submit" >
                                            <span class="top">Submit</span>
                                            <span class="bottom">Submit</span>
                                        </button>
                                    </div>
                                </Col>
                            </Row>
                        </form>
                    </div>
                </Col>

            </Row>
        </>
    )
}
